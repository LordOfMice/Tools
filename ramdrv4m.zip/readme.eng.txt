Universal RAM Drive for Windows 9x.

Contents:
RAMDRV4M.PDR - driver
RAMDRV4M.INF - installation file
RAMDRV4M.REG - examples of settings
ParamsBySize.exe   - auxiliary programs for calculation of
ParamsByEndAddr.exe  parameters
SPEED\*.* - speed comparison of different RAM Drives.

Installation:
Install in the Control Panel via Add New Hardware
(Hard Drive Controllers).

Uninstall:
Delete "RAM Drive 4M Controller" in Device Manager.
Instead of deleting you can temporary disable the controller
in Device Manager or, in case of a problem, rename it before
Windows booting:
%windir%\SYSTEM\IOSUBSYS\RAMDRV4M.PDR

Features description:
1. Memory support above 4GiB (default mode).
Primary purpose of creating this software.
The architectural limitation on the size of such RAM Drive is 1TiB.
No additional settings are required in this mode.
2. A full-fledged 32-bit protected mode driver.
3. High speed of operation. see SPEED\*.* comparison.
JFYI, the code from Walter Oney used for example in RAMDSK98.
4. Can utilize RAM Drives created in memory
by other software. In particular, it is compatible with
RAMDSK32/64 from RLoew. Once again, when used together with RAMDSK64.COM
no additional settings are required.
5. It consumes only 4MiB of virtual address space.
In addition to the real memory used for RAM Drive itself, of course.
6. Works on Pentium and higher class processors 
(i.e. it does not work on 80486).

Description of settings (see RAMDRV4M.REG for usage examples):

- setting for the memory areas used for the drive (up to 4 pieces):
"Chunk?.Base"=dword:00000000
"Chunk?.Size"=dword:00000000
Intended mainly for organizing a drive (or a chunk of a drive)
in memory below 4GiB. There is a small protection against possible error:
the area is checked to be unused by the OS Memory Manager.
The units of measure are pages of 4MiB. For convenience of calculating
by usual addresses there are two programs:
ParamsByEndAddr.exe (range) and ParamsBySize.exe (starting address + size).
 
Note that modern BIOSes have a floating memory map
from reboot to reboot even without any change in hardware or
BIOS settings so when specifying the memory area to be used,
you should make a tolerance for the worst case.

To use memory above 4GiB you should not set anything.
But if you want to limit the size of such drive,
you can set the parameter Chunk0.Size without setting Chunk0.Base.

- the above-mentioned check by the Memory Manager of no-use 
of RAM Drive memory in OS:
"OSMemoryCheck"=hex:FF
to disable control set to 0. It should be disabled only for
drives in memory under OS control.

- determining cluster size on a FAT32 volume
"FAT32ClusterShift"=hex:1B
by default - 27, 4KiB cluster is used for drivers up to 64GiB,
8KiB - up to 128GiB, 16KiB - up to 256GiB and 32KiB - over 256GiB.
The value is calculated as log2(drive size in bytes)-9.
For example:
"FAT32ClusterShift"=hex:17
- 4KiB cluster is used for drives up to 4GiB
"FAT32ClusterShift"=hex:20
- 4KiB cluster is used for drives up to 1TiB
(i.e. up to the maximum possible value)

- parameter of using FAT16 on large partitions:
"UseFAT16"=hex:FF
Values:
0 - do not use (use FAT32),
1 - use,
2 and more or not set - define according to FAT32 support in OS:
DOS 7.0 - to use, DOS 7.10+ - not to use.
 
- parameter of using a drive already created earlier in memory:
"UseGoodDrive"=hex:00
use of the drive after stopping and starting the controller in the 
Device Manager. The default is off. It is practically safe to turn it on.
 
- just for fun:
"UseGoodDriveAfterReboot"=hex:00
use of the drive after a "hot" reboot. It is disabled by default.
It is not safe to turn it on even for drivers with memory higher than 4GiB - on modern 
BIOSes, the drive header at the beginning of the 4GiB+ address space may be preserved,
but the memory is changed somewhere in the middle of the address space.
(It's not clear why, but that's the way it is). So it is necessary to first proof
(copy something on the drive to the whole drive size, reboot and then compare
it with the original data). To give you an example: on my laptop rebooting works
neatly, but on the new working machine - not anymore, memory changes around
5 gigabyte.

- checking for third-party drives in memory at start address:
"CheckExternalVolume"=hex:FF
enabled by default. If a drive is detected, there are two options
(by configuration) - it is either used or left under the control of the
of the old software, with use option enabled by default:
"GrabRMVolume"=hex:FF
"GrabExternalVolume"=hex:FF.
The first parameter defines the use of known DOS drives
(e.g. RAMDSK32/64), the second - all other drives (no examples yet)

- use of global memory pages (on feature supporting processors):
"PageGlobal"=hex:FF
enabled by default, gives a small speed gain

- maximum I/O packet size:
"MaximumTransferLength"=dword:FFFFFFFFFF
unlimited by default. The minimum value is dword:00010000 (64KiB)

- creating or using any drive without any checks
"RawImageSectorCount"=dword:00000000
disabled by default. "RawImageSectorCount" = dword:FFFFFFFF -
setup the size in a standard way, useful for
drives in memory above 4GiB

- parameters for virtual drive, heads and sectors per track
"RawImageHeads"=hex:00
"RawImageSectorsPerTrack"=hex:00
not set by default, autodetection by LBA Assisted Translation method

- additional operations with the image before using it:
"RawImagePrepare"=hex:00
default is to do nothing.
Bitmask:
0x01 - clear the first 32 sectors
0x02 - set boot mark 0xAA55 at the end of the zero sector
0x04 - set NT disk signature in zero sector
0x08 - set FAT boot signature at the beginning of the zero sector

- use uncached memory access of drive:
"UncachedMode"=hex:00
by default is off, use cached access
