SCSI LBA 64-bit Helper for Win9x

Contents:
LBA64HLP.VXD
LBA64HLP.REG - default settings

Installation:
Copy LBA64HLP.VXD to %windir%\SYSTEM\IOSUBSYS\

Uninstall:
Delete LBA64HLP.VXD from %windir%\SYSTEM\IOSUBSYS\

Description of settings:
By default, drives with more than 4G sectors
are mounted in read only mode,
DISKVSD behavior for reporting drive size for INT 13
for drives with less than 4G sectors is not corrected.

To enable the most complete features, you should create/modify
these registry keys:

[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\VxD\LBA64HLP]
; Corrects the disk size for INT 13 by DISKVSD.
; It reduces LBA size to geometric size, and in the geometric size itself
; reserves one cylinder. Modern operating systems, on the other hand,
; show and partition the full media size - there is some incompatibility.
"LBA32FullSize"=hex:01

;Write permission for drives with more than 4G sectors
"WriteAllowed"=hex:01

;Force calculation of CHS parameters by LBA Assisted algorithm
"ForceLBAAssisted"=hex:01

Compatibility:
Should work with any driver + controller + drive supporting SCSI protocol
in general and SCSI LBA 64-bit in particular.

Standard SCSI drivers for Win9x are SCSIPORT.PDR + .MPD, NTMAPHLP.PDR
and USBMPHLP.PDR. For the SCSIPORT.PDR + .MPD pair, it is the .MPD part
that defines support, SCSIPORT.PDR just translates SCSI requests.

Tested on Windows 98 SE with Windows ME USB stack (USBMPHLP.PDR)
and with drivers for SiI controllers (for SiI 3112R specifically, but should
work with the recent drivers for any SiI chips).
HGST HUS726060ALE610 drive (6TB), SiI 3112R controller and
USB-SATA bridge JMicron JMS578 used.

WARNING!!!
RLoew made similar improvement (in his recognizable style
- he patched DISKVSD.VXD from Windows 98 SE)
in Terabyte Pack Plus. DO NOT USE the patched version of
DISKVSD.VXD with LBA64HLP.VXD.
