GPT (GUID Partition Table) TSD (Type-Specific Driver) for Win9x
With manual settings can mount any partition too like MBR-invisible partition
in upper space on MBR partitioned large drive or EFI System partition.

Tested with VFAT and Paragon NTFS

Contents:
GPTTSDRO.VXD - Read Only Version

!!! USE AT YOUR OWN RISK !!!
GPTTSDRW.VXD - Read and Write version
!!! USE AT YOUR OWN RISK !!!

GPTTSD.REG - default settings
GPTTSD_USER_PARTITIONS.REG - user-defined partitions

Installation:
Copy the selected version (ONLY ONE VERSION)
to %windir%\SYSTEM\IOSUBSYS\.

Uninstall:
Delete the selected version from %windir%\SYSTEM\IOSUBSYS\

Description of settings:
By default, partitions are mounted in the safest mode:
1. Location on disk within first 4G sectors
2. If the first limitation is overridden, then the size is less than 4G sectors
3. If the second limitation is overridden, then no writing is allowed if the size
more than 4G sectors (for writable version)

To enable the most complete features, you should create/modify
the following registry keys:

[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\VxD\GPTTSD]

;sectors higher than 4G are allowed to be accessed
;your disk driver MUST SUPPORT reading/writing of such sectors
"LBA64Allowed"=hex:01

;auto selection of the handler (DISKTSD/GPTTSD) by checking
;the address of the last sector of partition against limit of 4G
;with LBA64Allowed enabled.
;if you have all partitions not exceeding 4G, then they all are 
;processed by DISKTSD and GPTTSD is unloaded from memory
"SmartType"=hex:01

;the maximum size of the mounted partition in sectors: 0 - WITHOUT LIMITATIONS
"MaxPartitionSize"=dword:00000000

;for writeable version
;write access to partitions with size higher than 4G sectors is allowed
"LargeWriteAllowed"=hex:01

The following registry keys describe how user partitions can be mounted:

[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\VxD\GPTTSD]
; If you does not want GPT to be processed, user defined partitions only:
"MountGPT"=hex:00

; Set this to non zero value to enable processing of Registry keys
; described below
"MountUserPartitions"=hex:01

; xxxxxxxx - hexadecimal value of Windows NT ID of media
; (DWORD at offset 01B8h in MBR), must be non zero
[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\VxD\GPTTSD\xxxxxxxx]
; "n"=dword:YYYYYYYY - Low DWORD value of 64-bit LBA start of partition n
; where n counts from zero without holes, i.e. 0, 1, 2...
; "nH"=dword:ZZZZZZZZ - High DWORD value of 64-bit LBA start of partition n
; See comment below how to set this value for partitions 
; that begins below 4G sectors

; !!! Warning - if you have partition that begins below 4G sectors and ends
; above 4G sectors you SHALL set up ZERO value for high part ("0H" here) of LBA:
"0"=dword:FFFFFFFE
"0H"=dword:00000000
; !!! OTOH if you have partition that begins and ends below 4G sectors
; you SHALL NOT set up ANY value for high part of LBA,
; the key ("1H" here) SHOULD ABSENT:
"1"=dword:A0000000
"1H"=-
