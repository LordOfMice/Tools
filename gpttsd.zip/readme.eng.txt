GPT (GUID Partition Table) TSD (Type-Specific Driver) for Win9x

Tested with VFAT and Paragon NTFS

Contents:
GPTTSDRO.VXD - Read Only Version

!!! USE AT YOUR OWN RISK !!!
GPTTSDRW.VXD - Read and Write version
!!! USE AT YOUR OWN RISK !!!

GPTTSD.REG - default settings

Installation:
Copy the selected version (ONLY ONE VERSION)
to %windir%\SYSTEM\IOSUBSYS\.

Uninstall:
Delete the selected version from %windir%\SYSTEM\IOSUBSYS\

Description of settings:
By default, partitions are mounted in the safest mode:
1. Location on disk within first 4G sectors
2. If the first limitation is overridden, then the size is less than 4G sectors
3. If the second limitation is overridden, then no writing is allowed if the size
more than 4G sectors (for writable version)

To enable the most complete features, you should create/modify
the following registry keys:

[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\VxD\GPTTSD]

;sectors higher than 4G are allowed to be accessed
;your disk driver MUST SUPPORT reading/writing of such sectors
"LBA64Allowed"=hex:01

;the maximum size of the mounted partition in sectors: 0 - WITHOUT LIMITATIONS
"MaxPartitionSize"=dword:00000000

;for writeable version
;write access to partitions with size higher than 4G sectors is allowed
"LargeWriteAllowed"=hex:01
