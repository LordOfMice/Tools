Win9x VCACHE Protection Error Fix (.VXD version of original CREGFIX.COM),
primarily for Windows ME

Contents:
CREGFIX.VXD
INSTALL\    - Install examples
UNINSTALL\  - Uninstall examples

Installation:
1. Copy CREGFIX.VXD to %windir%\SYSTEM\
2. Add to %windir%\SYSTEM.INI and to %windir%\SYSTEM.CB in [386Enh] section
this line:

device=CREGFIX.VXD

Uninstall:
1. Delete (or comment) from %windir%\SYSTEM.INI and
from %windir%\SYSTEM.CB in [386Enh] section this line:

device=CREGFIX.VXD

2. Delete CREGFIX.VXD from %windir%\SYSTEM\
