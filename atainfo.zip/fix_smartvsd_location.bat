@echo off
if exist %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD goto Nothing
echo %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD
echo is absent. Try to fix...
echo=

if not exist %windir%\SYSTEM\SMARTVSD.VXD goto NoSource

move %windir%\SYSTEM\SMARTVSD.VXD %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD

echo=

if exist %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD goto Success

echo Something went wrong.
echo Try to move
echo %windir%\SYSTEM\SMARTVSD.VXD
echo to
echo %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD
goto End

:Nothing
echo %windir%\SYSTEM\IOSUBSYS\SMARTVSD.VXD
echo is present already. Nothing to do.
goto End

:NoSource
echo %windir%\SYSTEM\SMARTVSD.VXD
echo is absent too. Can not fix problem.
echo You need to find update with SMARTVSD.VXD for your system.
goto End

:Success
echo Success. You need to reboot.

:End
echo=
pause
