#ifndef SCSI64_H
#define SCSI64_H

#define SCSI_SRV_ACT_IN 0x9E  // SERVICE ACTION IN
  #define SCSI_RD_CAPAC16 0x10  // Read Capacity (16) (O)

#define SCSI_SRV_ACT_OUT  $9F // SERVICE ACTION OUT

#define SCSIOP_READ16              0x88
#define SCSIOP_WRITE16             0x8A
#define SCSIOP_WRITE_VERIFY16      0x8E
#define SCSIOP_VERIFY16            0x8F
#define SCSIOP_SYNCHRONIZE_CACHE16 0x91

#define SENSE_RESPONSE_FIXED_CURRENT       0x70
#define SENSE_RESPONSE_FIXED_DEFERRED      0x71
#define SENSE_RESPONSE_DESCRIPTOR_CURRENT  0x72
#define SENSE_RESPONSE_DESCRIPTOR_DEFERRED 0x73


#define SENSE_DESCRIPTOR_TYPE_INFORMATION   0x00
#define SENSE_DESCRIPTOR_TYPE_COMMAND       0x01
#define SENSE_DESCRIPTOR_TYPE_SENSE_KEY     0x02
#define SENSE_DESCRIPTOR_TYPE_FRU           0x03
#define SENSE_DESCRIPTOR_TYPE_STREAM        0x04 //SSC-3+
#define SENSE_DESCRIPTOR_TYPE_BLOCK         0x05 //SBC-2+
#define SENSE_DESCRIPTOR_TYPE_OSD_OBJECT    0x06 //OSD-1+
#define SENSE_DESCRIPTOR_TYPE_OSD_INTEGRITY 0x07 //OSD-1+
#define SENSE_DESCRIPTOR_TYPE_OSD_ATTRIBUTE 0x08 //OSD-1+
#define SENSE_DESCRIPTOR_TYPE_ATA_RETURN    0x09 //SAT-1+

#include <pshpack1.h>

typedef struct _READ_CAPACITY_DATA_EX {
    ULARGE_INTEGER LogicalBlockAddress;
    ULONG BytesPerBlock;
    UCHAR Flags;
    UCHAR Reserved[19];
} READ_CAPACITY_DATA_EX, *PREAD_CAPACITY_DATA_EX;

//
// Standard 10-byte CDB
//

typedef struct {
    UCHAR OperationCode;
    UCHAR RelativeAddress : 1;
    UCHAR Reserved1 : 2;
    UCHAR ForceUnitAccess : 1;
    UCHAR DisablePageOut : 1;
    UCHAR LogicalUnitNumber : 3;
    UCHAR LogicalBlockByte0;
    UCHAR LogicalBlockByte1;
    UCHAR LogicalBlockByte2;
    UCHAR LogicalBlockByte3;
    UCHAR Reserved2;
    UCHAR TransferBlocksMsb;
    UCHAR TransferBlocksLsb;
    UCHAR Control;
} CDB10, *PCDB10;

//		
// Standard 16-byte CDB
//

typedef struct {
    UCHAR OperationCode;
    UCHAR RelativeAddress : 1;
    UCHAR Reserved1 : 2;
    UCHAR ForceUnitAccess : 1;
    UCHAR DisablePageOut : 1;
    UCHAR LogicalUnitNumber : 3;
    UCHAR LogicalBlock[8];      // [0]=MSB, [7]=LSB
    UCHAR TransferLength[4];    // [0]=MSB, [3]=LSB
    UCHAR Reserved2;
    UCHAR Control;
} CDB16, *PCDB16;

typedef struct _SENSE_DATA_DESCRIPTOR {
    UCHAR ResponseCode:7;                //00
    UCHAR Reserved1:1;                   //00
    UCHAR SenseKey:4;                    //01
    UCHAR Reserved2:4;                   //01
    UCHAR AdditionalSenseCode;           //02
    UCHAR AdditionalSenseCodeQualifier;  //03
    UCHAR Reserved3[3];                  //04
    UCHAR AdditionalSenseLength;         //07
    UCHAR DescriptorsData[0];            //08
} SENSE_DATA_DESCRIPTOR, *PSENSE_DATA_DESCRIPTOR; 

typedef struct _SENSE_DESCRIPTOR {
    UCHAR DescriptorType;                //00
    UCHAR AdditionalLength;              //01
    UCHAR DescriptorData[0];             //02
} SENSE_DESCRIPTOR, *PSENSE_DESCRIPTOR; 

#include <poppack.h>

#endif // SCSI64_H
